# 글로벌 리테일 성과 분석

굴하뎉섮 데이터 스튜디오가 생성한 **교육용 합성 데이터**와 Power BI Desktop 스타터 프로젝트입니다.

## 바로 시작하기

1. 압축을 푼 뒤 `PowerBI/데이터경로_자동설정.cmd`를 더블클릭합니다.
2. `PowerBI/글로벌_리테일_성과_분석.pbip`를 Power BI Desktop에서 엽니다.
3. 새로 고침 후 페이지별 안내 슬롯에 권장 시각화를 배치합니다.
4. 필요하면 `PowerBI/theme.json`을 보기 > 테마 > 테마 찾아보기에서 적용합니다.

## 도메인 × 국가 N:M 매핑

- 관광·호텔: KR, CN, JP, US, GB, DE, FR, CA, AU, IN, BR, IT, ES, MX, ID, TR, SA, NL, CH, PL, SE, BE, AR, IE, IL, AE, TH, VN, SG, MY, PH, NZ, NO, DK, FI, AT, PT, CZ, GR, CL, CO, ZA, EG, NG, PK, BD, RO, HU, UA, KE
- 여행객만족도: KR, JP

## 데이터 생성 우선순위

1. 학습자 업로드 데이터: 100점
2. 도메인 템플릿: 60점
3. 기본 합성 규칙: 20점

- 학습자 데이터: 업로드 없음

- 분석 기간: 2024-01-01 ~ 2026-07-31
- 국가: 50개

## 데이터 규모

- `dim_domain.csv`: 2행
- `dim_country.csv`: 50행
- `bridge_domain_country.csv`: 52행
- `dim_date.csv`: 943행
- `dim_entity.csv`: 20,000행
- `dim_item.csv`: 480행
- `fact_transactions.csv`: 100,000행
- `fact_interactions.csv`: 100,000행
- `fact_feedback.csv`: 100,000행

> 모든 데이터는 현실적 패턴을 모사한 가상 데이터이며 실제 개인·기관·거래를 나타내지 않습니다.

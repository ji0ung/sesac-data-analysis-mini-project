from pathlib import Path
import re
import sys

powerbi = Path(__file__).resolve().parent
data = (powerbi.parent / "data").resolve()
models = sorted(powerbi.glob("*.SemanticModel/definition/tables/*.tmdl"))
updated = 0
verified = 0
errors = []

if not models:
    errors.append("SemanticModel의 TMDL 테이블 파일을 찾지 못했습니다.")

for model in models:
    csv_path = (data / f"{model.stem}.csv").resolve()
    if not csv_path.is_file():
        errors.append(f"CSV 없음: {csv_path}")
        continue
    source = model.read_text(encoding="utf-8")
    replacement = f'File.Contents("{csv_path}")'
    changed = re.sub(r'File\.Contents\("[^"\r\n]+\.csv"\)', lambda _: replacement, source)
    if changed != source:
        model.write_text(changed, encoding="utf-8")
        updated += 1
    if replacement in changed:
        verified += 1
    else:
        errors.append(f"경로 구문을 찾지 못함: {model.name}")

guide = powerbi / "데이터경로_설정안내.md"
guide.write_text(
    "# 데이터 경로 설정\n\n"
    f"현재 Power BI 프로젝트 경로: `{powerbi}`\n\n"
    f"현재 CSV 데이터 경로: `{data}`\n\n"
    f"경로 검증 완료: **{verified}개 테이블**\n\n"
    "Power BI Desktop을 이미 열어 둔 상태에서 경로를 변경했다면 프로젝트를 닫고 `.pbip` 파일을 다시 여세요.\n",
    encoding="utf-8",
)

print(f"데이터 경로 검증 완료: {verified}/{len(models)}개 테이블")
print(f"이번 실행에서 변경: {updated}개 테이블")
print(f"Power BI 폴더: {powerbi}")
print(f"CSV 데이터 폴더: {data}")
if errors:
    print("\n[오류]")
    for error in errors:
        print(f"- {error}")
    sys.exit(1)
print("\n설정이 정상입니다. Power BI Desktop을 닫았다가 .pbip 파일을 다시 여세요.")

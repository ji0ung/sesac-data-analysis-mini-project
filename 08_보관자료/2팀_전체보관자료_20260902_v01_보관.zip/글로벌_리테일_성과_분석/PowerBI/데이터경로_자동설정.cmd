@echo off
chcp 65001 > nul
cd /d "%~dp0"
where python > nul 2> nul
if not errorlevel 1 (
    python "데이터경로_자동설정.py"
    goto :done
)
where py > nul 2> nul
if not errorlevel 1 (
    py -3 "데이터경로_자동설정.py"
    goto :done
)
echo [오류] Python 3를 찾을 수 없습니다.
:done
echo.
pause
